const add = (a: number, b: number) => {
  return a + b;
};
